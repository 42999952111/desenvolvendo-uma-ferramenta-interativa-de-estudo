criaCartao(
    'Histórias',
    'Em que dia eu nasci?',
    'Nasci dia:31/08/2007'
)

criaCartao(
    'Histórias',
    'Qual é minha cor preferida?',
    'Minha cor preferida é preto'
)

criaCartao(
    'Histórias',
    'Qual é minha comida favorita?',
    'Minha comida favorita é lasanha'
)

criaCartao(
    'Histórias',
    'Qual lugar do mundo eu gostaria de conhecer?',
    'Um lugar do mundo que eu gostaria de conhecer é a ilha de Santorini na Grécia'
)

criaCartao(
    'Histórias',
    'Que hobby ou atividade eu gostaria de experimentar?',
    'Pular de paraquedas'
)

criaCartao(
    'Histórias',
    'Qual é minha profissão dos sonhos?',
    'Minha profissão dos sonhos é ser Desembargadora'
)

criaCartao(
    'Histórias',
    'Qual é a minha estação do ano favorita?',
    'Minha estação do ano favorita é o outono'
)
criaCartao(
    'Histórias',
    'Minha preferência é filmes ou séries?',
    'Série com certeza'
)
criaCartao(
    'Histórias',
    'Qual é meu esporte preferido?',
    'Meu esporte preferido é o vôlei'
)
